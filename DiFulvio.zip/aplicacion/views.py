from django.shortcuts import render
from .models import Hogares

# Create your views here.
def home(request):
    return render (request, "aplicacion/home.html")
def hogares(request):
    contexto = {'Hogares': Hogares.objects.all()}
    return render (request, "aplicacion/hogares.html", contexto)

def centros(request):
    return render (request, "aplicacion/centros.html")