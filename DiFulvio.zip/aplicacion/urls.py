from django.urls import path, include
from .views import *

urlpatterns = [
    path ('', home, name="home"),
    path ('Hogares', hogares, name="hogares"),
    path ('Centros', centros, name="centros"),
]